# задание №4
from math import sqrt
print('Введите коэффициенты квадратного уравнения:')
a = int(input('Введите коэффициент a '))
b = int(input('Введите коэффициент b '))
c = int(input('Введите коэффициент c '))
d = (b**2) - (4*a*c)
if d < 0:
    print('Корней нет')
else:
    square_1 = (-b - sqrt(d)) / 2*a
    square_2 = (-b + sqrt(d)) / 2*a
    print(f'Корни квадратного уравнения: {round(square_1)}, {round(square_2)}')
