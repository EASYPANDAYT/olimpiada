// задание №2
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first string: ");
        String firstStr = scanner.nextLine();

        System.out.print("Enter the second string: ");
        String secondStr = scanner.nextLine();

        if (firstStr.length() == secondStr.length()) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }
    }
}
