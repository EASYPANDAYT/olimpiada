
digs = input('Введите элементы через пробел: ').split()
digs = map(int, digs)
digs = list(digs)


def bubble_sorting(digs: list) -> None:
    counter = 0
    for dig in digs:
        replace = False
        for i in range(len(digs) - 1):
            counter += 1
            if digs[i] < digs[i+1]:
                digs[i], digs[i + 1] = digs[i + 1], digs[i]
                replace = True
        if not replace:
            print('Кол-во сравнений:', counter)
            return
    print('Кол-во сравнений:', counter)


bubble_sorting(digs)
print(digs)
